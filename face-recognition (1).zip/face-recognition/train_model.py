import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import pickle

data_path = './face_data/'
image_paths = [os.path.join(data_path, f) for f in os.listdir(data_path) if f.endswith('.jpg')]

X = []  # face data
y = []  # labels

std = (50,50)

for image_path in image_paths:
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    img_resized = cv2.resize(image, std)
    X.append(img_resized.ravel())
    y.append(os.path.split(image_path)[-1].split("_")[0])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train an SVM classifier
clf = SVC(kernel='linear', probability=True)
clf.fit(X_train, y_train)

# Save the classifier
with open("face_recognizer.pkl", "wb") as f:
    pickle.dump(clf, f)

print("Model trained and saved!")
