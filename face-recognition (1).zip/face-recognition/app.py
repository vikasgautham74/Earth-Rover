from flask import Flask, render_template, request, redirect, url_for, Response
import threading
import cv2 
from face_recognise import recognize_face, capture_faces  # Import functions from your script

app = Flask(__name__)

video_stream = cv2.VideoCapture(0)  # Use Pi Camera. Update this line as per your requirement to use Pi Camera.

def generate_frames():  # Generate frames for video stream
    while True:
        success, frame = video_stream.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/')
def index():
    return render_template('index.html')  # Render the main HTML page

@app.route('/capture', methods=['POST'])
def capture():
    name = request.form.get('name')
    if name:
        threading.Thread(target=capture_faces, args=(name,)).start()
    return redirect(url_for('index'))

@app.route('/recognize')
def recognize():
    return render_template('recognize.html')  # Render the recognize page with video feed

@app.route('/start_recognize', methods=['POST'])
def start_recognize():
    threading.Thread(target=recognize_face).start()  # Start recognize_face in a new thread
    return 'OK'

@app.route('/start_recognizing', methods=['POST'])
def start_recognizing():
    # Start the face recognition process here.
    # You might use a thread to run it in the background
    threading.Thread(target=recognize_face).start()  # Assuming recognize_face is your face recognition function
    return 'Face Recognition Started'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5005, debug=True)  # Run the Flask app
