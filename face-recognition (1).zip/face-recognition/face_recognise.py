import face_recognition
import cv2
import os
import pickle
import picamera
from picamera.array import PiRGBArray
from face_captures import capture_faces

# Load the trained SVM classifier
with open("face_recognizer.pkl", "rb") as f:
    clf = pickle.load(f)

known_face_encodings = []
known_face_names = []

# Load each face sample and learn how to recognize it
data_path = './face_data/'
image_paths = [os.path.join(data_path, f) for f in os.listdir(data_path) if f.endswith('.jpg')]

for image_path in image_paths:
    current_image = face_recognition.load_image_file(image_path)
    encodings = face_recognition.face_encodings(current_image)

    if encodings:
        face_encoding = encodings[0]
        known_face_encodings.append(face_encoding)
        known_face_names.append(os.path.split(image_path)[-1].split("_")[0])  # Extract name from filename


def recognize_face(frame=None):
    with picamera.PiCamera() as camera:
        camera.resolution = (640, 480)
        camera.framerate = 32
        raw_capture = PiRGBArray(camera, size=(640, 480))

        for frame in camera.capture_continuous(raw_capture, format="bgr", use_video_port=True):
            image = frame.array
            
            small_frame = cv2.resize(image, (0, 0), fx=0.5, fy=0.5)
            rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            if frame is not None:
                process_this_frame = True  # to skip frames
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                face_names = []
                for face_encoding in face_encodings:
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.5)
                    name = "Unknown"
                    if True in matches:
                        first_match_index = matches.index(True)
                        name = known_face_names[first_match_index]
                    face_names.append(name)

                for (top, right, bottom, left), name in zip(face_locations, face_names):
                    cv2.rectangle(image, (left*2, top*2), (right*2, bottom*2), (0, 255, 0), 2)
                    cv2.putText(image, name, (left*2 + 6, bottom*2 - 6), cv2.FONT_HERSHEY_DUPLEX, 0.5, (255, 255, 255), 1)

                process_this_frame = not process_this_frame
                cv2.imshow('Video', image)

            raw_capture.truncate(0)  # Clear the stream for the next frame

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cv2.destroyAllWindows()




if __name__ == "__main__":
    choice = input("Do you want to capture faces or recognize? (capture/recognize): ")
    if choice == "capture":
        individual_name = input("Enter the name of the individual: ")
        capture_faces(individual_name)
    elif choice == "recognize":
        recognize_face()
    else:
        print("Invalid choice!")
