import cv2
import os

def capture_single_face(face_cascade, cap, name, count):
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        return count

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        count += 1
        face_data_path = "./face_data/{}_{}.jpg".format(name, count)
        cv2.imwrite(face_data_path, gray[y:y+h, x:x+w])

    cv2.imshow('Face Capture', frame)
    cv2.waitKey(1)  # Add a small delay for display purposes
    return count

def capture_faces(name, num_samples=50, frame_skip=3):
    if not os.path.exists('face_data'):
        os.makedirs('face_data')

    cap = cv2.VideoCapture(0)
    cap.set(3, 320)  # Set width
    cap.set(4, 240)  # Set height
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    count = 0

    while os.path.exists(f"./face_data/{name}_{count+1}.jpg"):
        count += 1

    head_positions = ["Look straight", "Turn your head to the left", "Turn your head to the right", "Tilt your head up", "Tilt your head down"]

    for position in head_positions:
        print(position ,"and press 'c'")
        cv2.waitKey(0)
        frame_count = 0
        while count < (head_positions.index(position) + 1) * num_samples / 5:
            if frame_count % frame_skip == 0:
                count = capture_single_face(face_cascade, cap, name, count)
            ret, _ = cap.read()  # Grab frame even if we're skipping
            frame_count += 1

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    individual_name = input("Enter the name of the individual: ")
    capture_faces(individual_name)
